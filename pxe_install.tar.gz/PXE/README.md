自动pxe装机脚本
暂时匹配centos7.
*光盘镜像要挂载到 /mnt 下 脚本才能找
安装完服务后也可自动卸载，并提供卸载脚本
系统安装是mini的，并添加oracle用户，有其他要求自行修改脚本
密码是一个空格
rpm -Uvh --forec --nodeps *.rpm

