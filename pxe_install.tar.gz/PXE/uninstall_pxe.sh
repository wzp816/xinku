#!/bin/bash

server=(
dhcp
http
xinetd 
tftp )
for i in ${server[@]}
do
pkill $i 
done

rm -rf /etc/dhcp/dhcpd.conf
rm -rf /etc/xinetd.d/tftp
rm -rf /var/lib/tftpboot/pxelinux.cfg
rm -rf /var/www/html/ks.cfg
rm -rf /var/www/html/centos

server_b=`yum list installed | grep -e dhcp -e tftp -e xinetd -e http -e syslinux | awk '{print $1}'`
for i in $server_b
do
yum autoremove -y  $i
	if [ $? -eq 0 ];then
		echo "uninstall pxe ok"
	else
		echo  "no uninstalled error"
	fi
done

