#!/bin/bash
yum  -y install  *.rpm 
local_ip=`ip addr | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep  -v 127.0.0.1 | head  -1`
ip=`ip addr | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep  -v 127.0.0.1 | head  -1 | cut -b 1-11`

cat > /etc/dhcp/dhcpd.conf <<EOF
subnet ${ip}.0 netmask 255.255.255.0 { 
  range ${ip}.100 ${ip}.200;
  option domain-name-servers ${local_ip};
  option routers ${ip}.1;
  default-lease-time 600;
  max-lease-time 7200;
  next-server ${local_ip}; 
  filename "pxelinux.0";
}
EOF

cat > /etc/xinetd.d/tftp   <<EOF
service tftp
{
        socket_type             = dgram
        protocol                = udp
        wait                    = yes
        user                    = root
        server                  = /usr/sbin/in.tftpd
        server_args             = -s /var/lib/tftpboot
        disable                 = no
        per_source              = 11
        cps                     = 100 2
        flags                   = IPv4
}
EOF

mkdir /var/lib/tftpboot/pxelinux.cfg
cat > /var/lib/tftpboot/pxelinux.cfg/default <<EOF
default linux
timeout 600
menu clear
menu background splash.png
menu title CentOS 7 pxe_server
menu vshift 8
menu rows 18
menu margin 8
menu helpmsgrow 15
menu tabmsgrow 13
menu color border * #00000000 #00000000 none
menu color sel 0 #ffffffff #00000000 none
menu color title 0 #ff7ba3d0 #00000000 none
menu color tabmsg 0 #ff3a6496 #00000000 none
menu color unsel 0 #84b8ffff #00000000 none
menu color hotsel 0 #84b8ffff #00000000 none
menu color hotkey 0 #ffffffff #00000000 none
menu color help 0 #ffffffff #00000000 none
menu color scrollbar 0 #ffffffff #ff355594 none
menu color timeout 0 #ffffffff #00000000 none
menu color timeout_msg 0 #ffffffff #00000000 none
menu color cmdmark 0 #84b8ffff #00000000 none
menu color cmdline 0 #ffffffff #00000000 none
menu tabmsg Press Tab for full configuration options on menu items.
menu separator # insert an empty line
menu separator # insert an empty line
label linux
  menu label ^Install CentOS 7 pxe_server
  menu default
  kernel vmlinuz
  append initrd=initrd.img   ks=http://${local_ip}/ks.cfg quiet
EOF

cat > /var/www/html/ks.cfg <<EOF
#version=DEVEL
# System authorization information
auth --enableshadow --passalgo=sha512
# Use CDROM installation media
url --url=http://${local_ip}/centos/
#cdrom
# Use graphical install
graphical
# Run the Setup Agent on first boot
firstboot --enable
ignoredisk --only-use=sda
# Keyboard layouts
keyboard --vckeymap=cn --xlayouts='cn'
# System language
lang zh_CN.UTF-8

# Network information
network  --bootproto=dhcp --device=ens33 --ipv6=auto --activate
network  --hostname=localhost.localdomain

# Root password
rootpw --iscrypted $6$7Sq1jlDHJH9qX7v2$/RcuufvIYENn/SPlzmVvARroZBbNurcfCXe0pJNwQR4L0lxnMMUfROvrvyM/49wtdq59P4XCQxX1kaqdsHsHh1
# System services
services --enabled="chronyd"
# System timezone
timezone Asia/Shanghai --isUtc
user --name=oracle --password=$6$eCjVDim3gnjqP8iU$oxDrxk9C2i2DdKTxrTg2tgXthGonlg2X1I3N//UmRS2ufDM8bV7H038i6kQCi2VZbXmQCARNrduM7hJeDdJLX0 --iscrypted --gecos="oracle"
# System bootloader configuration
bootloader --location=mbr --boot-drive=sda
autopart --type=lvm
# Partition clearing information
#clearpart --none --initlabel
clearpart --all  --initlabel

%packages
@^minimal
@core
chrony

%end

%addon com_redhat_kdump --disable --reserve-mb='auto'

%end

%anaconda
pwpolicy root --minlen=6 --minquality=1 --notstrict --nochanges --notempty
pwpolicy user --minlen=6 --minquality=1 --notstrict --nochanges --emptyok
pwpolicy luks --minlen=6 --minquality=1 --notstrict --nochanges --notempty
%end

EOF

mkdir /var/www/html/centos
cp -r /mnt/* /var/www/html/centos/
cp /usr/share/syslinux/pxelinux.0 		/var/lib/tftpboot/
cp /mnt/images/pxeboot/{vmlinuz,initrd.img} 	/var/lib/tftpboot/
cp /mnt/isolinux/{vesamenu.c32,boot.msg}   	/var/lib/tftpboot/
#cp /mnt/isolinux/isolinux.cfg  			/var/lib/tftpboot/pxelinux.cfg/default

systemctl start dhcpd  &&  systemctl enable dhcpd 
systemctl start httpd  &&  systemctl enable httpd
systemctl start xinetd &&  systemctl enable xinetd
count=`ss  -ntplu | grep -e ":80" -e ":67" -e ":69" | wc -l`
[ $count -ne 3 ] && echo "服务运行异常" || echo "服务运行正常"

